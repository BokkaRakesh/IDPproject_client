import { InfoIconDirective } from './info-icon.directive';

describe('InfoIconDirective', () => {
  it('should create an instance', () => {
    const directive = new InfoIconDirective();
    expect(directive).toBeTruthy();
  });
});
